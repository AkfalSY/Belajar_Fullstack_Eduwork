<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> Dashboard <?php $__env->endSlot(); ?>

    
    <div class="grid gap-4 sm:grid-cols-3">
        <div class="rounded-2xl border border-neutral-200 bg-white p-5">
            <p class="text-sm text-neutral-500">Total Kategori</p>
            <p class="mt-1 text-3xl font-extrabold text-neutral-900"><?php echo e($totalCategories); ?></p>
        </div>
        <div class="rounded-2xl border border-neutral-200 bg-white p-5">
            <p class="text-sm text-neutral-500">Total Produk</p>
            <p class="mt-1 text-3xl font-extrabold text-[#EA6A2E]"><?php echo e($totalProducts); ?></p>
        </div>
        <div class="rounded-2xl border border-neutral-200 bg-white p-5">
            <p class="text-sm text-neutral-500">Total Clicks</p>
            <p class="mt-1 text-3xl font-extrabold text-neutral-900"><?php echo e($jumlahClickProduct); ?></p>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\ecommerce\resources\views/dashboard/index.blade.php ENDPATH**/ ?>