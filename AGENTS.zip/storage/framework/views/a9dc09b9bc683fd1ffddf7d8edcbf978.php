<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name', 'Jingga')); ?></title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap"
        rel="stylesheet">

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>

<body class="bg-neutral-100 antialiased" style="font-family: 'Plus Jakarta Sans', sans-serif;">

    <?php
        $menus = [
            [
                'label' => 'Dashboard',
                'href' => route('dashboard.index'),
                'active' => request()->routeIs('dashboard.*'),
                'icon' =>
                    'M4 5a1 1 0 0 1 1-1h5v7H4V5Zm10-1h5a1 1 0 0 1 1 1v3h-6V4ZM4 13h6v7H5a1 1 0 0 1-1-1v-6Zm10-3h6v9a1 1 0 0 1-1 1h-5v-10Z',
            ],
            [
                'label' => 'Product',
                'href' => url('/products'),
                'active' => request()->is('products*'),
                'icon' => 'm12 3 8 4.5v9L12 21l-8-4.5v-9L12 3Zm0 9 8-4.5M12 12v9M12 12 4 7.5',
            ],
            [
                'label' => 'Kategori Product',
                'href' => route('category.index'),
                'active' => request()->routeIs('category.*'),
                'icon' => 'M3 12V4h8l10 10-8 8L3 12Zm5-5h.01',
            ],
        ];
    ?>

    <div x-data="{ sidebar: false }" class="min-h-screen">

        
        <div x-show="sidebar" x-cloak @click="sidebar = false" class="fixed inset-0 z-30 bg-black/50 lg:hidden"></div>

        
        <aside
            class="fixed inset-y-0 left-0 z-40 flex w-64 flex-col border-r border-neutral-200 bg-white transition-transform duration-300 lg:translate-x-0"
            :class="sidebar ? 'translate-x-0' : '-translate-x-full'">

            <a href="<?php echo e(route('dashboard.index')); ?>" class="flex items-center gap-x-2 px-6 py-6">
                <span
                    class="grid size-9 place-items-center rounded-xl bg-[#EA6A2E] text-lg font-extrabold text-white">J</span>
                <span class="text-xl font-extrabold text-neutral-900">Jingga</span>
            </a>

            <nav class="flex flex-1 flex-col gap-y-1 px-4">
                <p class="px-3 pb-2 pt-2 text-xs font-semibold uppercase tracking-wider text-neutral-400">Menu</p>

                <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e($menu['href']); ?>"
                        class="flex items-center gap-x-3 rounded-xl px-3 py-3 text-sm font-semibold transition-colors
                   <?php echo e($menu['active'] ? 'bg-[#EA6A2E] text-white' : 'text-neutral-600 hover:bg-neutral-100 hover:text-neutral-900'); ?>">
                        <svg class="size-5 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor"
                            stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                            <path d="<?php echo e($menu['icon']); ?>" />
                        </svg>
                        <?php echo e($menu['label']); ?>

                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </nav>

            <div class="m-4 rounded-2xl bg-neutral-900 p-4 text-white">
                <p class="text-sm font-bold">Butuh bantuan?</p>
                <p class="mt-1 text-xs text-neutral-400">Hubungi tim Jingga kapan saja.</p>
            </div>
        </aside>

        
        <div class="lg:pl-64">

            
            <header
                class="sticky top-0 z-20 flex items-center gap-x-4 border-b border-neutral-200 bg-white px-4 py-4 sm:px-8">
                <button type="button" @click="sidebar = true"
                    class="rounded-lg p-2 text-neutral-700 hover:bg-neutral-100 lg:hidden" aria-label="Buka menu">
                    <svg class="size-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"
                        stroke-linecap="round">
                        <path d="M4 7h16M4 12h16M4 17h16" />
                    </svg>
                </button>

                
                <form method="GET" action="<?php echo e(url()->current()); ?>"
                    class="flex w-full max-w-md items-center gap-x-2 rounded-xl border border-neutral-200 bg-neutral-50 px-4 py-2.5 focus-within:border-[#EA6A2E] focus-within:ring-4 focus-within:ring-[#EA6A2E]/15">
                    <svg class="size-5 shrink-0 text-neutral-400" fill="none" viewBox="0 0 24 24"
                        stroke="currentColor" stroke-width="2" stroke-linecap="round">
                        <path d="m21 21-4.3-4.3M17 10.5a6.5 6.5 0 1 1-13 0 6.5 6.5 0 0 1 13 0Z" />
                    </svg>
                    <input type="text" name="q" value="<?php echo e(request('q')); ?>" placeholder="Cari..."
                        class="w-full border-0 bg-transparent p-0 text-sm text-neutral-900 placeholder:text-neutral-400 focus:ring-0" />
                </form>

                
                <div class="ml-auto">
                    <?php if (isset($component)) { $__componentOriginaldf8083d4a852c446488d8d384bbc7cbe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldf8083d4a852c446488d8d384bbc7cbe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dropdown','data' => ['align' => 'right','width' => '48']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dropdown'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['align' => 'right','width' => '48']); ?>
                         <?php $__env->slot('trigger', null, []); ?> 
                            <button
                                class="flex items-center gap-x-3 rounded-xl p-1.5 hover:bg-neutral-100 focus:outline-none">
                                <span
                                    class="grid size-9 place-items-center rounded-full bg-neutral-900 text-sm font-bold text-white">
                                    <?php echo e(strtoupper(substr(Auth::user()->name, 0, 1))); ?>

                                </span>
                                <span class="hidden text-left sm:block">
                                    <span
                                        class="block text-sm font-semibold leading-tight text-neutral-900"><?php echo e(Auth::user()->name); ?></span>
                                    <span class="block text-xs text-neutral-500"><?php echo e(Auth::user()->email); ?></span>
                                </span>
                                <svg class="hidden size-4 text-neutral-500 sm:block" fill="none" viewBox="0 0 24 24"
                                    stroke="currentColor" stroke-width="2">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="m6 9 6 6 6-6" />
                                </svg>
                            </button>
                         <?php $__env->endSlot(); ?>

                         <?php $__env->slot('content', null, []); ?> 
                            <?php if (isset($component)) { $__componentOriginal68cb1971a2b92c9735f83359058f7108 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal68cb1971a2b92c9735f83359058f7108 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dropdown-link','data' => ['href' => route('profile.edit')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('profile.edit'))]); ?>Profile <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal68cb1971a2b92c9735f83359058f7108)): ?>
<?php $attributes = $__attributesOriginal68cb1971a2b92c9735f83359058f7108; ?>
<?php unset($__attributesOriginal68cb1971a2b92c9735f83359058f7108); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal68cb1971a2b92c9735f83359058f7108)): ?>
<?php $component = $__componentOriginal68cb1971a2b92c9735f83359058f7108; ?>
<?php unset($__componentOriginal68cb1971a2b92c9735f83359058f7108); ?>
<?php endif; ?>
                            <form method="POST" action="<?php echo e(route('logout')); ?>">
                                <?php echo csrf_field(); ?>
                                <?php if (isset($component)) { $__componentOriginal68cb1971a2b92c9735f83359058f7108 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal68cb1971a2b92c9735f83359058f7108 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dropdown-link','data' => ['href' => route('logout'),'onclick' => 'event.preventDefault(); this.closest(\'form\').submit();']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('logout')),'onclick' => 'event.preventDefault(); this.closest(\'form\').submit();']); ?>Log
                                    Out <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal68cb1971a2b92c9735f83359058f7108)): ?>
<?php $attributes = $__attributesOriginal68cb1971a2b92c9735f83359058f7108; ?>
<?php unset($__attributesOriginal68cb1971a2b92c9735f83359058f7108); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal68cb1971a2b92c9735f83359058f7108)): ?>
<?php $component = $__componentOriginal68cb1971a2b92c9735f83359058f7108; ?>
<?php unset($__componentOriginal68cb1971a2b92c9735f83359058f7108); ?>
<?php endif; ?>
                            </form>
                         <?php $__env->endSlot(); ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldf8083d4a852c446488d8d384bbc7cbe)): ?>
<?php $attributes = $__attributesOriginaldf8083d4a852c446488d8d384bbc7cbe; ?>
<?php unset($__attributesOriginaldf8083d4a852c446488d8d384bbc7cbe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldf8083d4a852c446488d8d384bbc7cbe)): ?>
<?php $component = $__componentOriginaldf8083d4a852c446488d8d384bbc7cbe; ?>
<?php unset($__componentOriginaldf8083d4a852c446488d8d384bbc7cbe); ?>
<?php endif; ?>
                </div>
            </header>

            
            <main class="p-4 sm:p-8">
                <?php if(isset($header)): ?>
                    <h1 class="mb-6 text-2xl font-extrabold tracking-tight text-neutral-900"><?php echo e($header); ?></h1>
                <?php endif; ?>

                <?php echo e($slot); ?>

            </main>
        </div>
    </div>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\ecommerce\resources\views\layouts\app.blade.php ENDPATH**/ ?>